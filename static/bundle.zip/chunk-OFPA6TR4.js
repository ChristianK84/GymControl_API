var o="1.0.5";export{o as a};
